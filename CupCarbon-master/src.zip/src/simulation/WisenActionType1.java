package simulation;

public class WisenActionType1 extends WisenAction {

	@Override
	public void execute() {
		
	}

}
