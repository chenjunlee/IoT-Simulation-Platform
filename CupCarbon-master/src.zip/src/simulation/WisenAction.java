package simulation;

public abstract class WisenAction {
	
	public abstract void execute() ;

}
