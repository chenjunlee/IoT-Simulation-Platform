package solver;

public class SolverProxyParams {

	public static String proxyset = "" ;
	public static String host = "" ;
	public static String port = "" ;
	
}
