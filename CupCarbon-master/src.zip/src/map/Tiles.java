package map;

public class Tiles {

	public static final String TILE0 = "http://a.basemaps.cartocdn.com/light_all/";
	public static final String TILE1 = "http://a.basemaps.cartocdn.com/dark_all/";
	public static final String TILE2 = "cuptile_land.png";
	public static final String TILE3 = "cuptile_small_grid.png";
	public static final String TILE4 = "cuptile_small_grid_dark.png";
	public static final String TILE5 = "cuptile_black.png";
	public static final String TILE6 = "cuptile_white.png";
	public static final String TILE7 = "cuptile_grid.png";
	public static final String TILE8 = "cuptile_book.png";
	public static final String TILE9 = "cuptile_grid2.png";
	public static final String TILE10 = "http://mt0.google.com/vt/lyrs=m&hl=en";
	public static final String TILE11 = "http://mt0.google.com/vt/lyrs=s&hl=en";
	public static final String TILE12 = "https://tiles.wmflabs.org/bw-mapnik/";
	
}
