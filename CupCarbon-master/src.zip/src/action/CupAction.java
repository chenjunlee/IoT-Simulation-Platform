package action;

public abstract class CupAction {
	
	public CupAction() {}
	
	public abstract void execute();
	public abstract void antiExecute();
	
}
