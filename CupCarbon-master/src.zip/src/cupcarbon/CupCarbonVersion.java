package cupcarbon;

public final class CupCarbonVersion {
	public static final String VERSION = "U-One 4.2";
	public static final String YEAR = "2020";
	public static final int UPDATE = 25;
}
