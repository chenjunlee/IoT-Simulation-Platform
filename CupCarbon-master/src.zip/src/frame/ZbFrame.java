package frame;

public class ZbFrame {

	public static String generateDataFrame16(String s) {
		return s;
	}
	
	public static String generateDataFrame64(String s) {
		return s;
	}
	
	public static String generateAtFrame(String s) {
		return s;
	}
	
	public static String readFrame(String s) {
		return s;
	}
	
}
