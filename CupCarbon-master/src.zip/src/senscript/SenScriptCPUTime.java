package senscript;

public class SenScriptCPUTime {

	public static double cpuTime_data = 0.5e-12;
	
}
